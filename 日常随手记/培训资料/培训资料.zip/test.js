// import dayjs from 'dayjs'
var dayjs = require('dayjs')
dayjs().format()

// 
function test（） {
  alert('今天天气很好！')

}
/*
* @author: 
*/